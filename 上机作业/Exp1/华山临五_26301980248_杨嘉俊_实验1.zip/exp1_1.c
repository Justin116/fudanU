#include <stdio.h>

int main() {
  float singPrice, payPrice;
  int amount;
  scanf("%f%d%f", &singPrice, &amount, &payPrice);
  float totalPrice, extraPrice;
  totalPrice = singPrice * amount;
  extraPrice = payPrice - totalPrice;
  printf("Ӧ����%.2fԪ\n", totalPrice);
  printf("�����%.2fԪ", extraPrice);

  return 0;
}